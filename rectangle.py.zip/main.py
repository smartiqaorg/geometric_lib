def area(a, b): 
    return a * b 

def perimeter(a, b): 
    return a + b 